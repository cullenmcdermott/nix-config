---
name: home-assistant
description: This skill should be used when helping with Home Assistant setup, including creating automations, modifying dashboards, checking entity states, debugging automations via traces, and managing the smart home configuration. Use this for queries about HA entities, YAML automation/dashboard generation, or troubleshooting HA issues.
---

# Home Assistant Helper

## Overview

This skill provides tools and workflows for working with Home Assistant installations. It enables querying the live HA instance for entities, services, and configuration data, debugging automations through trace analysis, and generating YAML configurations for automations and dashboards.

**Key Capabilities:**
- Query entities, states, and services from the live HA installation
- Search for similar entities to use as examples
- Retrieve automation traces for debugging
- Generate YAML configurations for copy/paste into HA
- Find real examples from the user's setup to inform new configurations

## Core Workflow

When helping with Home Assistant tasks, follow this general approach:

1. **Understand the requirement** - What is the user trying to accomplish?
2. **Discover existing entities** - Use scripts to find relevant entities in their setup
3. **Find similar examples** - Search for existing automations or entities that do something similar
4. **Generate YAML** - Create well-formed YAML that can be copied directly into HA
5. **Explain the configuration** - Describe what the YAML does and how to install it

## Available Scripts

All scripts require the `HA_TOKEN` environment variable to be set, which contains the Home Assistant long-lived access token. The HA instance is available at `https://ha.cullen.rocks`.

### Entity Discovery

#### `ha_get_entities.py [domain]`
Retrieve all entities, optionally filtered by domain.

**Usage:**
```bash
python3 scripts/ha_get_entities.py           # All entities
python3 scripts/ha_get_entities.py light     # Just lights
python3 scripts/ha_get_entities.py sensor    # Just sensors
```

**When to use:** To discover what entities are available, especially when building new automations.

#### `ha_get_state.py <entity_id>`
Get the current state and attributes of a specific entity.

**Usage:**
```bash
python3 scripts/ha_get_state.py light.living_room
```

**When to use:** To check current state, available attributes, or confirm an entity exists.

#### `ha_search_similar_entities.py <pattern>`
Search for entities matching a pattern in their entity_id or friendly_name.

**Usage:**
```bash
python3 scripts/ha_search_similar_entities.py "bedroom"
python3 scripts/ha_search_similar_entities.py "motion"
python3 scripts/ha_search_similar_entities.py "temperature"
```

**When to use:** To find entities related to what the user wants to automate. This is especially useful for finding examples before creating new automations.

### Automation Management

#### `ha_get_automations.py [search_term]`
Retrieve all automations, optionally filtered by search term.

**Usage:**
```bash
python3 scripts/ha_get_automations.py              # All automations
python3 scripts/ha_get_automations.py motion       # Automations with 'motion'
python3 scripts/ha_get_automations.py light        # Automations with 'light'
```

**When to use:** To find existing automations that are similar to what the user wants to create. Use these as templates.

#### `ha_get_automation_trace.py <automation_id> [num_traces]`
Get recent execution traces for an automation, useful for debugging.

**Usage:**
```bash
python3 scripts/ha_get_automation_trace.py automation.bedroom_motion_light 1
python3 scripts/ha_get_automation_trace.py automation.bedroom_motion_light 5
```

**When to use:** When debugging why an automation isn't working, to see execution history, trigger data, and action results.

### Service Discovery

#### `ha_get_services.py [domain]`
Get all available services with descriptions and field information.

**Usage:**
```bash
python3 scripts/ha_get_services.py              # All services
python3 scripts/ha_get_services.py light        # Just light services
python3 scripts/ha_get_services.py climate      # Just climate services
```

**When to use:** To discover what services are available and what parameters they accept.

### Configuration

#### `ha_get_config.py`
Get Home Assistant configuration including version, location, and components.

**Usage:**
```bash
python3 scripts/ha_get_config.py
```

**When to use:** To understand the HA setup, available integrations, or system information.

### Service Calling

#### `ha_call_service.py <domain> <service> <json_data>`
Call a Home Assistant service (use with caution).

**Usage:**
```bash
python3 scripts/ha_call_service.py light turn_on '{"entity_id": "light.living_room"}'
```

**When to use:** Rarely. Generally only for testing or when the user explicitly asks to control something.

## Typical Workflows

### Creating a New Automation

1. **Understand the goal** - Ask clarifying questions about triggers, conditions, and actions
2. **Find similar entities** - Use `ha_search_similar_entities.py` to find relevant entities
3. **Search for similar automations** - Use `ha_get_automations.py` with search terms to find examples
4. **Review existing automation** - If a similar one exists, examine its structure
5. **Generate YAML** - Create well-formatted YAML with:
   - Descriptive alias
   - Clear description
   - Appropriate triggers
   - Relevant conditions
   - Necessary actions
   - Proper mode (single, restart, queued, parallel)
6. **Provide copy-paste YAML** - Format for easy copying into HA configuration
7. **Explain** - Describe what the automation does and how to add it to HA

### Debugging an Automation

1. **Get the automation state** - Use `ha_get_state.py automation.automation_name`
2. **Check recent traces** - Use `ha_get_automation_trace.py` to see execution history
3. **Analyze trace data** - Look at:
   - Trigger information (did it trigger?)
   - Condition results (did conditions pass?)
   - Action execution (did actions run? any errors?)
   - Variables and context
4. **Identify the issue** - Based on trace data
5. **Suggest fix** - Provide corrected YAML or configuration changes

### Modifying a Dashboard

1. **Understand desired changes** - What should the dashboard show?
2. **Find relevant entities** - Use entity discovery scripts
3. **Generate Lovelace YAML** - Create dashboard card configuration
4. **Provide copy-paste YAML** - User will manually add to their dashboard
5. **Explain card configuration** - Describe options and customization

### Exploring Entity States

1. **Use search or domain filtering** - Find entities of interest
2. **Check specific states** - Get detailed state information
3. **Report findings** - Present relevant information clearly

## Important Notes

### YAML Output Format

When generating YAML configurations, always:
- Use proper YAML formatting with 2-space indentation
- Include helpful comments where appropriate
- Provide descriptive aliases and descriptions
- Use appropriate trigger platforms (state, time, numeric_state, etc.)
- Include mode settings (single, restart, queued, parallel)
- Format for easy copy-paste into HA

### Manual Installation Required

The user must manually copy/paste generated YAML into Home Assistant. Make this clear and provide instructions:
- For automations: Configuration → Automations & Scenes → Add Automation → Edit in YAML
- For dashboards: Dashboard → Edit Dashboard → Raw Configuration Editor
- For configuration.yaml additions: Edit the file and restart HA

### Browser Automation for Screenshots

If the user asks for screenshots of dashboards or wants to see the current UI state, the Playwright browser automation tools can be used to navigate to the HA instance and capture screenshots. The user will need to handle authentication.

### Service Calls

Be cautious about calling services that change state. Generally only do this when explicitly requested by the user or for testing purposes.

### Entity Naming

All entities follow the pattern `domain.object_id` where common domains include:
- `light` - Lights
- `switch` - Switches
- `sensor` - Sensors (read-only)
- `binary_sensor` - Binary sensors (on/off)
- `climate` - Thermostats
- `automation` - Automations
- `script` - Scripts
- `input_boolean`, `input_number`, `input_select`, `input_text`, `input_datetime` - Helper entities
- `person` - People
- `device_tracker` - Device tracking
- `camera` - Cameras
- `media_player` - Media players
- `cover` - Covers (blinds, garage doors)
- `fan` - Fans
- `lock` - Locks

### Common Trigger Platforms

- `state` - Entity state changes
- `numeric_state` - Numeric value crosses threshold
- `sun` - Sunrise/sunset
- `time` - Specific time
- `time_pattern` - Time pattern (every N minutes)
- `event` - HA event fired
- `webhook` - Webhook trigger
- `zone` - Enter/leave zone
- `device` - Device-specific trigger

### Common Condition Platforms

- `state` - Entity state equals value
- `numeric_state` - Numeric comparison
- `time` - Time window
- `sun` - Before/after sunrise/sunset
- `zone` - Person in zone
- `template` - Template evaluation

### Automation Modes

- `single` - Don't start new run if already running
- `restart` - Restart automation if triggered while running
- `queued` - Queue runs if already running
- `parallel` - Allow multiple simultaneous runs
