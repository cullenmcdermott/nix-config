#!/usr/bin/env python3
"""
Get the most recent trace for a Home Assistant automation.

Usage:
    python3 ha_get_automation_trace.py <automation_entity_id> [num_traces]

Example:
    python3 ha_get_automation_trace.py automation.bedroom_motion_light 1

Requires HA_TOKEN environment variable to be set.
"""

import os
import sys
import json
import urllib.request
import urllib.error

HA_URL = "https://ha.cullen.rocks"

def get_automation_traces(automation_id, num_traces=1):
    """Fetch recent traces for an automation."""
    token = os.environ.get("HA_TOKEN")
    if not token:
        print("Error: HA_TOKEN environment variable not set", file=sys.stderr)
        sys.exit(1)

    # Get list of trace IDs
    url = f"{HA_URL}/api/trace/{automation_id}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req) as response:
            traces = json.loads(response.read().decode())

            if not traces:
                print(f"No traces found for {automation_id}", file=sys.stderr)
                return []

            # Get detailed info for requested number of traces
            detailed_traces = []
            for trace in traces[:num_traces]:
                trace_id = trace['run_id']
                detail_url = f"{HA_URL}/api/trace/{automation_id}/{trace_id}"
                detail_req = urllib.request.Request(detail_url, headers=headers)
                with urllib.request.urlopen(detail_req) as detail_response:
                    detailed_trace = json.loads(detail_response.read().decode())
                    detailed_traces.append(detailed_trace)

            return detailed_traces

    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"Error: Automation '{automation_id}' not found or has no traces", file=sys.stderr)
        else:
            print(f"HTTP Error {e.code}: {e.reason}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def main():
    if len(sys.argv) < 2:
        print("Usage: ha_get_automation_trace.py <automation_entity_id> [num_traces]", file=sys.stderr)
        sys.exit(1)

    automation_id = sys.argv[1]
    num_traces = int(sys.argv[2]) if len(sys.argv) > 2 else 1

    traces = get_automation_traces(automation_id, num_traces)
    print(json.dumps(traces, indent=2))

if __name__ == "__main__":
    main()
